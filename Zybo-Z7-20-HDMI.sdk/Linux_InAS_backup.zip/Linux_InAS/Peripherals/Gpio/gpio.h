/*
 * gpio.h
 *
 *  Created on: 08-Mar-2024
 *      Author: scope
 */

#ifndef PERIPHERALS_GPIO_GPIO_H_
#define PERIPHERALS_GPIO_GPIO_H_

/**************************** INCLUDES ******************************/

/**************************** MACROS ********************************/

/**************************** TYPEDEFS ******************************/

/**************************** EXPORTED VARIABLES ********************/

/**************************** FUNCTION PROTOTYPES *******************/
void gpio_rs485_init();
void gpio_rs485_tx_en();

#endif /* PERIPHERALS_GPIO_GPIO_H_ */
