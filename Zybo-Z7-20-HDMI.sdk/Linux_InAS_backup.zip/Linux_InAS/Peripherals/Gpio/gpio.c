/*
 * gpio.c
 *
 *  Created on: 08-Mar-2024
 *      Author: scope
 */

/**************************** INCLUDES ******************************/
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/fcntl.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <signal.h>
#include <sys/mman.h>
#include <unistd.h>

/**************************** EXTERN VARIABLES **********************/


/**************************** MACROS ********************************/


/**************************** TYPEDEFS ******************************/


/**************************** STATIC VARIABLES **********************/


/**************************** GLOBAL VARIABLES **********************/
uint32_t *p_gpio_rs485;

/**************************** FUNCTION PROTOTYPES *******************/


/**************************** FUNCTIONS *****************************/

void gpio_rs485_init()
{
	int fd_gpio_rs485;

	    off_t		rs485_en_base_address 	= 0x41210000;
	    size_t 		ip_size		= 64000;

	if((fd_gpio_rs485 = open("/dev/mem",O_RDWR | O_SYNC)) == -1)
	{
		printf("Access memory error");
		exit(1);
	}

	p_gpio_rs485 = (uint32_t *)mmap(NULL, ip_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd_gpio_rs485, rs485_en_base_address);
	if(p_gpio_rs485 == MAP_FAILED)
	{
		printf("gpio mapping failed\r\n");
		exit(1);
	}

	close(fd_gpio_rs485);
	printf("rs485 gpio init\r\n");
}

void gpio_rs485_tx_en()
{
	*((uint32_t*)p_gpio_rs485) = 0x04;
}
