/*
 * custom_uart.c
 *
 *  Created on: 08-Mar-2024
 *      Author: scope
 */

/**************************** INCLUDES ******************************/
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/fcntl.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <time.h>
#include <signal.h>
#include <sys/mman.h>
#include "timer.h"

/**************************** EXTERN VARIABLES **********************/


/**************************** MACROS ********************************/
#define 	CUSTOM_UART_1_BASE	(0x43C00000)
#define 	CUSTOM_UART_2_BASE	(0x43C10000)
#define		CUSTOM_UART_3_BASE	(0x43C20000)
#define		CUSTOM_UART_4_BASE	(0x43C30000)

#define		FIFO_WRITE_OFFSET	8
#define		FIFO_READ_OFFSET	9

/**************************** TYPEDEFS ******************************/


/**************************** STATIC VARIABLES **********************/


/**************************** GLOBAL VARIABLES **********************/
uint32_t 	*p32_axi_uart_1,
			*p32_axi_uart_2,
			*p32_axi_uart_3,
			*p32_axi_uart_4;

/**************************** FUNCTION PROTOTYPES *******************/


/**************************** FUNCTIONS *****************************/

void custom_uart_init()
{
	/* 	here all the custom AXI UART IP's will be mapped to virtual
	 * 	base address to it's corresponding physical base address
	 * 	allocated by the Vivado software. for more information regarding
	 * 	base addresses refer "Address Editor" in Vivado software
	 */

	int custom_uart_fd;

	size_t 				uart_size		= 64000;

	/*	Mapping the physical address of AXI Uart IP 1 into virtual address space
	 * 	of Linux kernel using method of "mmap"
	 * 	Mapping the physical address to virtual address using mmap for user space.
	 */
	if((custom_uart_fd = open("/dev/mem",O_RDWR | O_SYNC)) == -1)
	{
		printf("Access memory error");
		exit(1);
	}

	p32_axi_uart_1 = (uint32_t *)mmap(NULL, uart_size, PROT_READ|PROT_WRITE, MAP_SHARED, custom_uart_fd, CUSTOM_UART_1_BASE);
	if(p32_axi_uart_1 == MAP_FAILED)
	{
		printf("gpio mapping failed\r\n");
		exit(1);
	}

	close(custom_uart_fd);


	/*	Mapping the physical address of AXI Uart IP 2 into virtual address space
	 * 	of Linux kernel using method of "mmap"
	 * 	Mapping the physical address to virtual address using mmap for user space.
	 */
	if((custom_uart_fd = open("/dev/mem",O_RDWR | O_SYNC)) == -1)
	{
		printf("Access memory error");
		exit(1);
	}

	p32_axi_uart_2 = (uint32_t *)mmap(NULL, uart_size, PROT_READ|PROT_WRITE, MAP_SHARED, custom_uart_fd, CUSTOM_UART_2_BASE);
	if(p32_axi_uart_2 == MAP_FAILED)
	{
		printf("gpio mapping failed\r\n");
		exit(1);
	}

	close(custom_uart_fd);

	printf("AXI Uart 1 & 2 init\r\n");


}


int custom_uart_1_read(uint8_t *p8_rxdata,uint32_t u32_len)
{
	/* 	Initiate the timer function to wait in read function for predefined time
	 * 	according to read request -> 	1. Data command read request
	 * 									2. Config command read request
	 * 	Timer will start before reading from fifo starts and will wait for
	 * 	predefined time.
	 * 	If the timer expires and data is not read from fifo, it will return
	 * 	Error to the calling funciton.
	 */
	int 		i8_error;
	uint8_t 	u8_ret;
	uint32_t 	u32_count;

	struct itimerspec 	st_timer_specs_1;

	/* 	start the timer before start reading data from the Read FIFO */
    st_timer_specs_1.it_value.tv_sec = 2;
    st_timer_specs_1.it_value.tv_nsec = 0;
    st_timer_specs_1.it_interval.tv_sec = 0;
    st_timer_specs_1.it_interval.tv_nsec = 0;

    if (timer_settime(st_timerid_1, 0, &st_timer_specs_1, NULL) == -1)
    	perror("timer_1_settime");

    printf("timer set\r\n");

    u8_timer1_expired = 0;

	for(u32_count = 0 ; (u32_count < u32_len) ; u32_count++)
	{
		for(u8_ret = 1 ; (u8_ret == 1 && (u8_timer1_expired == 0)) ; )
		{
			u8_ret = *(volatile uint32_t*)(p32_axi_uart_1 + FIFO_READ_OFFSET);
		}
		if(u8_timer1_expired == 1)
			break;
		p8_rxdata[u32_count] = *(volatile uint32_t*)p32_axi_uart_1;

	}

	if(u32_count < (u32_len - 1))
	{
		return i8_error = -1;
	}
	else
	{
		/* 	Stop the Timer*/
		st_timer_specs_1.it_value.tv_sec = 0;
		if (timer_settime(st_timerid_1, 0, &st_timer_specs_1, NULL) == -1)
			perror("timer_1_settime");
		return i8_error = u32_count;
	}
}

void custom_uart_1_write(uint8_t *p8_txdata,uint32_t u32_len)
{
	uint32_t 	u32_count;
	uint8_t 	u8_ret;

	uint32_t 	u32_temp = 0;


	/*	For sending command to every Daughter board the command frame length
	 * 	is same for all commands.
	 */
	for(u32_count = 0 ; u32_count < u32_len ; u32_count++)
	{
		for(u8_ret = 0 ; u8_ret == 1 ; )
		{

			u8_ret = *(volatile uint32_t*)(p32_axi_uart_1 + FIFO_WRITE_OFFSET);
//			printf("wrf %d\r\n",u32_temp);
//			printf("w u8_ret %d\r\n",u8_ret);
			u32_temp++;
		}

		*(volatile uint32_t*)p32_axi_uart_1 = p8_txdata[u32_count];
		usleep(1);
	}
}

int8_t custom_uart_2_read(uint8_t *p8_rxdata,uint32_t u32_len)
{
	/* 	Initiate the timer function to wait in read function for predefined time
	 * 	according to read request -> 	1. Data command read request
	 * 									2. Config command read request
	 * 	Timer will start before reading from fifo starts and will wait for
	 * 	predefined time.
	 * 	If the timer expires and data is not read from fifo, it will return
	 * 	Error to the calling funciton.
	 */
	int8_t 		i8_error;
	uint8_t 	u8_ret;
	uint32_t 	u32_count;

	for(u32_count = 0 ; u32_count < u32_len ; u32_count++)
	{
		for(u8_ret = 1 ; u8_ret == 1 ; )
		{
			u8_ret = *(volatile uint32_t*)(p32_axi_uart_2 + FIFO_READ_OFFSET);
		}

		p8_rxdata[u32_count] = *(volatile uint32_t*)p32_axi_uart_2;
		//usleep(5);
	}

	if(u32_count < (u32_len - 1))
	{
		return i8_error = -1;
	}
	else
	{
		return i8_error = 0;
	}
}

void custom_uart_2_write(uint8_t *p8_txdata,uint32_t u32_len)
{
	uint32_t 	u32_count;
	uint8_t 	u8_ret;


	/*	For sending command to every Daughter board the command frame length
	 * 	is same for all commands.
	 */
	for(u32_count = 0 ; u32_count < u32_len ; u32_count++)
	{
		for(u8_ret = 0 ; u8_ret == 1 ; )
		{

			u8_ret = *(volatile uint32_t*)(p32_axi_uart_2 + FIFO_WRITE_OFFSET);
		}

		*(volatile uint32_t*)p32_axi_uart_2 = p8_txdata[u32_count];
		usleep(5);
	}
}

void custom_uart_fifo_reset(uint32_t *p32_custom_uart)
{
	int8_t 		i_ret;
	uint8_t 	u8_temp;

	uint32_t u32_count = 0;

	//printf("fifo reset\r\n");
	for(i_ret = 0 /*u8_ret = 0*/ ; i_ret == 0; )
	{
		//printf("frt %d\r\n",u32_count);
		i_ret = *(volatile uint32_t*)(p32_custom_uart + FIFO_READ_OFFSET);
		u8_temp = *(volatile uint32_t*)(p32_custom_uart);
//		printf("i_ret %d\r\n",i_ret);
//		printf("frt %d\r\n",u32_count);
		u32_count++;
	}
}
