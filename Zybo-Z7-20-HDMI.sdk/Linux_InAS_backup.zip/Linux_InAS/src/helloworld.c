/*
 * Copyright (c) 2012 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#include <stdio.h>

#include <semaphore.h>
#include <fcntl.h>
#include "app.h"
#include "gpio.h"
#include "custom_uart.h"
#include "timer.h"


#define 	SEM_SLOT_1			"/sem_slot_1"
#define 	SEM_SLOT_2			"/sem_slot_2"
#define 	SEM_SLOT_3			"/sem_slot_3"
#define 	SEM_SLOT_4			"/sem_slot_4"
#define 	SEM_READ_SOCKET		"/read_socket"

int main()
{
    printf("Hello World\r\n");
    printf("test for InAS without HDMI\r\n");

    /* 	create the Semaphores and Threads here and starts
     * 	use the main application only for idle purpose
     * 	OR cleaning objects purpose.
     */

	pthread_t 	t_id_read_socket,
				t_id_Slot_1,
				t_id_Slot_2,
				t_id_Slot_3,
				t_id_Slot_4;

	int 	i_ret;

	gpio_rs485_init();
	custom_uart_init();
	timer_init();

	sem_read_socket = sem_open(SEM_READ_SOCKET,O_CREAT,0660,1);
	if(sem_read_socket == SEM_FAILED)
	{
		perror("sem_Slot_1 :");
	}

	sem_Slot_1 = sem_open(SEM_SLOT_1,O_CREAT,0660,0);
	if(sem_Slot_1 == SEM_FAILED)
	{
		perror("sem_Slot_1 :");
	}

	sem_Slot_2 = sem_open(SEM_SLOT_2,O_CREAT,0660,0);
	if(sem_Slot_2 == SEM_FAILED)
	{
		perror("sem_Slot_1 :");
	}

	sem_Slot_3 = sem_open(SEM_SLOT_3,O_CREAT,0660,0);
	if(sem_Slot_3 == SEM_FAILED)
	{
		perror("sem_Slot_1 :");
	}

	sem_Slot_4 = sem_open(SEM_SLOT_4,O_CREAT,0660,0);
	if(sem_Slot_4 == SEM_FAILED)
	{
		perror("sem_Slot_1 :");
	}

	printf("Semaphores created\r\n");

	//    /* 	create threads necessary for the execution of all communication state-machines
	//     * 	for 4 slots.
	//     */
	i_ret = pthread_create(&t_id_read_socket,NULL,read_socket ,NULL);
	if(i_ret != 0)
	{
		perror("read_th");
	}

	i_ret = pthread_create(&t_id_Slot_1,NULL,communication_slot_1 ,NULL);
	if(i_ret != 0)
	{
		perror("Slot1_th");
	}

	printf("Threads created\r\n");
	i_ret = pthread_create(&t_id_Slot_2,NULL,communication_slot_2 ,NULL);
	if(i_ret != 0)
	{
		perror("Slot2_th");
	}
	//
	//    i_ret = pthread_create(&t_id_Slot_3,NULL,communication_slot_3 ,NULL);
	//    if(i_ret != 0)
	//    {
	//    	perror("Slot3_th");
	//    }
	//
	//    i_ret = pthread_create(&t_id_Slot_4,NULL,communication_slot_4 ,NULL);
	//    if(i_ret != 0)
	//    {
	//    	perror("Slot4_th");
	//    }

	/*	here program execution will not come to main program as all logic will be executed
	 * 	from threads
	 * 	check how program execution comes in main program after creating the required threads
	 * 	as it will help to clean up the buffers and memory files while program execution is ideal.
	 */
	while(1)
	{
		//sleep(2);
		//printf("%d %s\r\n", __LINE__,__FUNCTION__);
	}

	return 0;

    return 0;
}
