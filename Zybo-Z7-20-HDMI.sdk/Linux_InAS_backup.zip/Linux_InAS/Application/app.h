/*
 * app.h
 *
 *  Created on: 08-Mar-2024
 *      Author: scope
 */

#ifndef APPLICATION_APP_H_
#define APPLICATION_APP_H_

/**************************** INCLUDES ******************************/
#include <stdint.h>
#include <semaphore.h>
/**************************** MACROS ********************************/

/**************************** TYPEDEFS ******************************/
typedef struct frame_info
{
	uint16_t u16_header;
	uint16_t u16_card_address;
	uint16_t u16_identifier;
	uint16_t u16_activity;
	uint16_t u16_payload;
	uint16_t p16_data[21];
	uint16_t u16_checksum;
	uint16_t u16_footer;
}frame_info;

typedef enum states{	e_REQ_TEST_SETTINGS,
	e_REQ_HANDSHAKE,
	e_REQ_DATA,
	e_RESP,
	e_CONFIG_PARAMETERS,
	e_CONFIG_READY_FOR_TEST,
	e_CONFIG_OPTO_RECEIVED,
	e_CONFIG_DIAGNOTICS
}states;

typedef enum errors{	e_NO_ERR 				= 0,
	e_ERR_HEADER			= 0x0001,
	e_ERR_FOOTER	 		= 0x0002,
	e_ERR_CARD_ADDRESS	 	= 0x0004,
	e_ERR_CHECKSUM		 	= 0x0008,
	e_ERR_FRAME_IDENTIFIER 	= 0x0010,
	e_ERR_ITERATION			= 0x0020,
	e_ERR_ACTIVITY_CDOE		= 0X0040
}errors;

typedef enum Channel_name
{
	e_ch_1,
	e_ch_2,
	e_ch_3,
	e_ch_4,
	e_ch_5,
	e_ch_6,
	e_ch_7,
	e_ch_8,
	e_ch_9,
	e_ch_10,
	e_ch_11,
	e_ch_12
}Channel_name;

typedef struct coil_current
{
	uint8_t u8_ch_en[6];
	uint8_t u8_ch[6];
	uint16_t u16_ch_current_range[6];
}coil_current;

typedef struct travel
{
	uint8_t u8_ch_en[6];
	uint8_t u8_ch[6];
}travel;

typedef struct analog
{
	uint8_t u8_ch_en[12];
	uint8_t u8_ch[12];
}analog;

typedef struct test_parameters
{
	uint16_t u16_sampling_speed;
	uint16_t u16_trigger;
	uint16_t u16_plot_length;
	uint16_t u16_close_cmd;
	uint16_t u16_open_cmd;
	uint16_t u16_delay_toc;
	uint16_t u16_delay_tco;
	uint16_t u16_tim_auxiliary;
	uint16_t u16_tim_pir;
	uint16_t u16_dcrm_current;
	uint16_t u16_dcrm_resistance;
	uint16_t u16_scrm_current;
	uint16_t u16_scrm_resistance;
	uint16_t u16_travel_trans_type;
	uint16_t u16_travel_trans_mech;
	uint16_t u16_coil_current_range;
	uint16_t u16_coil_current_channels;
	uint16_t u16_travel_ch;
	uint16_t u16_travel_transducer;
	coil_current 	st_coil_curr;
	travel 			st_travel;
	analog			st_analog;
}test_parameters;

typedef struct card_info{
	uint8_t 	u8_slot;
	uint8_t 	u8_card_address;
	uint8_t 	u8_activity;
	uint8_t 	u8_ack_error;
	uint8_t 	u8_data_arrived;
	uint8_t 	u8_data_files[4];
	uint8_t 	u8_process_done;
	uint8_t 	u8_test;
	uint16_t	u16_error_value;
	test_parameters st_test_param;
	uint16_t 	u16_iterations;

}card_info;





/**************************** EXPORTED VARIABLES ********************/
extern sem_t 	*sem_read_socket,
				*sem_Slot_1,
				*sem_Slot_2,
				*sem_Slot_3,
				*sem_Slot_4;

extern test_parameters st_test_param;
/**************************** FUNCTION PROTOTYPES *******************/
void *communication_slot_1();
void *communication_slot_2();
void *communication_slot_3();
void *communication_slot_4();
void *read_socket();

#endif /* APPLICATION_APP_H_ */
